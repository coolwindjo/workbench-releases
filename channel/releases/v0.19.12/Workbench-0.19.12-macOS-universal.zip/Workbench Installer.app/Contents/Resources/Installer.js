/* JXA / Cocoa installer. No Node, Python, Homebrew or administrator access required. */
ObjC.import('Cocoa');
function run(argv) {
    var application=Application.currentApplication();application.includeStandardAdditions=true;
    var fm=$.NSFileManager.defaultManager,home=ObjC.unwrap($.NSHomeDirectory()),resources=argv[0];
    function str(v){return ObjC.unwrap(v);}
    function nil(v){return v===null||v===undefined||((typeof v==='object'||typeof v==='function')&&typeof v.isNil==='function'&&v.isNil());}
    function fileFailure(code,p,error){
        var detail='';try{var e=error;if(!nil(e))detail=str(e.localizedDescription)||'';}catch(ignore){}
        throw Error('['+code+'] '+p+(detail?'\n'+detail:''));
    }
    // AppKit NSInteger/NSModalResponse are signed longs on 64-bit macOS.
    // JXA may return a decimal STRING, so strict comparison with JS 1 fails.
    function cocoaInteger(value,label){
        if(value!==null&&(typeof value==='object'||typeof value==='function'))value=ObjC.unwrap(value);
        if(typeof value==='string'&&/^-?[0-9]+$/.test(value))value=Number(value);
        if(typeof value!=='number'||!isFinite(value)||Math.floor(value)!==value||Math.abs(value)>9007199254740991)
            throw Error('[COCOA_STATE_INVALID] Cannot read '+label+'. Close and reopen Workbench Setup. If this continues, report this code to the publisher.');
        return value;
    }
    function checked(control,label){return cocoaInteger(control.state,label)===1;}

    function exists(p){return Boolean(fm.fileExistsAtPath($(p)));}
    function read(p){var e=$();var s=$.NSString.stringWithContentsOfFileEncodingError($(p),$.NSUTF8StringEncoding,e);if(nil(s))fileFailure('FILE_READ_FAILED',p,e);return str(s);}
    function write(p,s){var e=$();if(!$(s).writeToFileAtomicallyEncodingError($(p),true,$.NSUTF8StringEncoding,e))fileFailure('FILE_WRITE_FAILED',p,e);}
    function mkdir(p){var e=$();if(!fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(p),true,$(),e))fileFailure('DIRECTORY_CREATE_FAILED',p,e);}
    function copy(a,b){var e=$();if(!fm.copyItemAtPathToPathError($(a),$(b),e))fileFailure('FILE_COPY_FAILED',a+' -> '+b,e);}
    function move(a,b){var e=$();if(!fm.moveItemAtPathToPathError($(a),$(b),e))fileFailure('FILE_MOVE_FAILED',a+' -> '+b,e);}
    function remove(p){var e=$();if(exists(p)&&!fm.removeItemAtPathError($(p),e))fileFailure('STAGE_REMOVE_FAILED',p,e);}
    function directoryNames(p){var e=$(),list=fm.contentsOfDirectoryAtPathError($(p),e);if(nil(list))fileFailure('DIRECTORY_LIST_FAILED',p,e);var names=ObjC.deepUnwrap(list);if(!Array.isArray(names))throw Error('[DIRECTORY_LIST_INVALID] '+p);return names;}
    function quote(p){return "'"+p.replace(/'/g,"'\\''")+"'";}
    function hash(p){return application.doShellScript('/usr/bin/shasum -a 256 '+quote(p)).split(/\s+/)[0];}
    function direct(p){var normalized=str($(p).stringByStandardizingPath);var real=str($(p).stringByResolvingSymlinksInPath);if(normalized!==real)throw Error('Choose a direct folder, not a symbolic link.');return normalized;}
    if(argv[0]==='--self-test'){
        console.log('SELFTEST begin');
        // Real Foundation smoke test, isolated from every user Vault and setting.
        var testDir=str($.NSTemporaryDirectory())+'workbench-installer-'+str($.NSUUID.UUID.UUIDString);
        try{
            console.log('SELFTEST mkdir');mkdir(testDir);console.log('SELFTEST write');write(testDir+'/note.txt','Native Cocoa test');
            console.log('SELFTEST read');if(read(testDir+'/note.txt')!=='Native Cocoa test')throw Error('Native read/write mismatch');
            console.log('SELFTEST list');if(directoryNames(testDir).indexOf('note.txt')<0)throw Error('Native listing mismatch');
            console.log('SELFTEST copy/move');copy(testDir+'/note.txt',testDir+'/copy.txt');move(testDir+'/copy.txt',testDir+'/moved.txt');
            if(read(testDir+'/moved.txt')!=='Native Cocoa test')throw Error('Native copy/move mismatch');
            console.log('SELFTEST enumerate');var iter=fm.enumeratorAtPath($(testDir)),found=0,item;
            while(!nil(item=iter.nextObject)){if(++found>10)throw Error('Native iterator failed to terminate');}
            if(found!==2)throw Error('Native iterator count mismatch');
            console.log('SELFTEST errors');var missingRead=false,missingList=false;
            try{read(testDir+'/missing.txt');}catch(e){missingRead=String(e).indexOf('FILE_READ_FAILED')>=0;}
            try{directoryNames(testDir+'/missing');}catch(e){missingList=String(e).indexOf('DIRECTORY_LIST_FAILED')>=0;}
            if(!missingRead||!missingList)throw Error('Native NSError/nil handling failed');
            return 'PASS native macOS installer: nil attributes, mkdir, read/write, listing, copy/move, iterator termination and NSError diagnostics';
        }finally{console.log('SELFTEST cleanup');remove(testDir);}
    }
    var meta=JSON.parse(read(resources+'/payload/payload.json')),terms=read(resources+'/payload/LICENSE.txt');
    var pluginId='agentic-workbench',legacyId='personal-workbench';
    function ownLegacy(dir){try{var m=JSON.parse(read(dir+'/manifest.json')),r=JSON.parse(read(dir+'/install-receipt.json'));return m.id===dir.split('/').pop()&&m.id!==pluginId&&m.name==='Workbench'&&m.author==='JoSH'&&r.schema===1&&r.product==='workbench'&&r.accepted===true;}catch(ignore){return false;}}
    Object.keys(meta.files).forEach(function(name){if(name.indexOf('/')>=0||name.indexOf('\\')>=0||hash(resources+'/payload/'+name)!==meta.files[name])throw Error('Package integrity check failed: '+name);});
    function install(vault,accepted,enable) {
        if(!accepted)throw Error('Accept the license before installing.');vault=direct(vault);
        var config=vault+'/.obsidian';if(!exists(config))throw Error('Choose an existing Obsidian Vault containing .obsidian.');direct(config);
        var parent=config+'/plugins';mkdir(parent);direct(parent);
        var previous=directoryNames(parent).filter(function(name){return ownLegacy(parent+'/'+name);});if(previous.length>1)throw Error('Multiple previous Workbench installations. Resolve the conflict first.');var oldId=previous[0]||legacyId;var dest=parent+'/'+pluginId,legacy=parent+'/'+oldId,id=str($.NSUUID.UUID.UUIDString).toLowerCase();direct(dest);direct(legacy);var migrate=ownLegacy(legacy);
        var stage=parent+'/.workbench-stage-'+id,backup=config+'/workbench-install-backups/'+id;direct(backup);
        var community=config+'/community-plugins.json';direct(community);var before=exists(community)?read(community):null;
        var enabled=before===null?[]:JSON.parse(before);if(!Array.isArray(enabled)||enabled.some(function(x){return typeof x!=='string';}))throw Error('Invalid community plugin list.');
        var hotkeys=config+'/hotkeys.json';direct(hotkeys);var keysBefore=exists(hotkeys)?read(hotkeys):null,keys=null;
        if(migrate&&keysBefore!==null){keys=JSON.parse(keysBefore);Object.keys(keys).forEach(function(name){if(name.indexOf(oldId+':')===0){var next=pluginId+name.slice(oldId.length);if(!(next in keys))keys[next]=keys[name];delete keys[name];}});}
        var moved=false,installed=false,legacyMoved=false;
        try{
            var source=exists(dest)?dest:migrate?legacy:null;if(source){var enumerator=fm.enumeratorAtPath($(source)),entry;if(nil(enumerator))throw Error('[DIRECTORY_ENUMERATION_FAILED] '+source);while(!nil(entry=enumerator.nextObject))direct(source+'/'+str(entry));copy(source,stage);}else mkdir(stage);
            Object.keys(meta.files).forEach(function(name){remove(stage+'/'+name);copy(resources+'/payload/'+name,stage+'/'+name);});
            if(!exists(stage+'/data.json'))write(stage+'/data.json',JSON.stringify({history:false,sync:false,classifierEnabled:false,routerBackend:'codex',execution:'auto'}));
            var now=new Date();
            write(stage+'/installation-consent.json',JSON.stringify({schema:1,product:'workbench',accepted:true,acceptedAt:now.toISOString(),termsSha256:meta.files['LICENSE.txt']}));
            mkdir(backup);if(before!==null)write(backup+'/community-plugins.before.json',before);
            if(keysBefore!==null)write(backup+'/hotkeys.before.json',keysBefore);
            if(exists(dest)){move(dest,backup+'/plugin');moved=true;}if(migrate){move(legacy,backup+'/legacy-plugin');legacyMoved=true;}move(stage,dest);installed=true;
            var wasEnabled=migrate&&enabled.indexOf(oldId)>=0;if(migrate)enabled=enabled.filter(function(x){return x!==oldId;});if((enable||wasEnabled)&&enabled.indexOf(pluginId)<0)enabled.push(pluginId);if(enable||migrate)write(community,JSON.stringify(enabled));if(keys)write(hotkeys,JSON.stringify(keys));
            write(backup+'/installation.json',JSON.stringify({product:'Workbench',version:meta.version,installedAt:now.toISOString()}));
            return 'Activate with your publisher-issued license key in Workbench.';
        }catch(error){if(installed)remove(dest);if(moved)move(backup+'/plugin',dest);if(legacyMoved)move(backup+'/legacy-plugin',legacy);if(before!==null)write(community,before);else remove(community);if(keysBefore!==null)write(hotkeys,keysBefore);throw error;}
        finally{remove(stage);}
    }
    var app=$.NSApplication.sharedApplication;app.setActivationPolicy($.NSApplicationActivationPolicyRegular);
    var window=$.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer($.NSMakeRect(0,0,840,590),7,$.NSBackingStoreBuffered,false);
    window.title='Workbench Setup';window.center;window.releasedWhenClosed=false;
    var content=window.contentView,body=$.NSView.alloc.initWithFrame($.NSMakeRect(222,90,586,470));content.addSubview(body);
    function label(parent,text,x,y,w,h,size,bold){var l=$.NSTextField.alloc.initWithFrame($.NSMakeRect(x,y,w,h));l.stringValue=$(text);l.bezeled=false;l.drawsBackground=false;l.editable=false;l.selectable=false;l.font=bold?$.NSFont.boldSystemFontOfSize(size):$.NSFont.systemFontOfSize(size);parent.addSubview(l);return l;}
    var side=$.NSView.alloc.initWithFrame($.NSMakeRect(0,0,196,590));side.wantsLayer=true;side.layer.backgroundColor=$.NSColor.colorWithCalibratedRedGreenBlueAlpha(.13,.11,.21,1).CGColor;content.addSubview(side);
    label(side,'W',28,455,140,95,62,true).textColor=$.NSColor.whiteColor;label(side,'Workbench',28,410,160,45,24,true).textColor=$.NSColor.whiteColor;
    var stepLabel=label(side,'',28,170,150,210,14,false);stepLabel.textColor=$.NSColor.colorWithCalibratedWhiteAlpha(.84,1);label(side,'JoSH\nVersion '+meta.version,28,32,160,60,12,false).textColor=$.NSColor.lightGrayColor;
    var step=0,accepted=false,enabled=true,vaultPath=home+'/.local/agent-workspaces/Obsidian/runtime/PersonalWorkbenchSandbox',closed=false,expiry='',agreeBox,vaultField,enableBox,closedBox;
    try{var known=JSON.parse(read(home+'/Library/Application Support/obsidian/obsidian.json')).vaults;var names=Object.keys(known);if(names.length)vaultPath=known[names[0]].path;}catch(ignore){}
    function alert(text){var a=$.NSAlert.alloc.init;a.messageText='Workbench';a.informativeText=$(text);a.runModal;}
    var actions;
    function button(parent,text,x,y,w,selector){var b=$.NSButton.alloc.initWithFrame($.NSMakeRect(x,y,w,36));b.title=$(text);b.bezelStyle=$.NSBezelStyleRounded;b.target=actions;b.action=selector;parent.addSubview(b);return b;}
    function checkbox(text,y,checked,selector){var b=button(body,text,0,y,580,selector);b.setButtonType($.NSSwitchButton);b.allowsMixedState=false;b.state=checked?1:0;return b;}
    function syncChecks(){
        try{
            if(step===1){accepted=checked(agreeBox,'license agreement');next.enabled=accepted;gateHint.stringValue=$(accepted?'':'Select the agreement checkbox to continue.');return accepted;}
            if(step===2){closed=checked(closedBox,'Obsidian closed confirmation');enabled=checked(enableBox,'plugin enable preference');next.enabled=closed;gateHint.stringValue=$(closed?'':'Confirm that Obsidian is closed to continue.');return closed;}
            return true;
        }catch(error){if(step===1)accepted=false;if(step===2)closed=false;next.enabled=false;gateHint.stringValue=$('Checkbox state could not be read. See the error details.');alert(String(error));return false;}
    }
    ObjC.registerSubclass({name:'WorkbenchInstallerActions',superclass:'NSObject',methods:{
        'applicationShouldTerminateAfterLastWindowClosed:':{types:['BOOL',['id']],implementation:function(){return true;}},
        'next:':{types:['void',['id']],implementation:function(){try{
            if(!syncChecks())return;
            if(step===2)vaultPath=str(vaultField.stringValue);
            if(step===3){if(application.doShellScript('/usr/bin/pgrep -x Obsidian >/dev/null && printf running || true')){alert('Close Obsidian first to avoid settings conflicts.');return;}next.enabled=false;back.enabled=false;next.title='Installing…';window.displayIfNeeded;expiry=install(vaultPath,accepted,enabled);}
            if(step===4){app.terminate($());return;}step++;render();
        }catch(error){next.enabled=true;back.enabled=true;next.title=$(step===3?'Install':'Continue');gateHint.stringValue=$('Installation stopped. Review the error before retrying.');alert(String(error));}}},
        'back:':{types:['void',['id']],implementation:function(){step--;render();}},
        'agree:':{types:['void',['id']],implementation:function(){syncChecks();}},
        'closed:':{types:['void',['id']],implementation:function(){syncChecks();}},
        'enable:':{types:['void',['id']],implementation:function(){syncChecks();}},
        'browse:':{types:['void',['id']],implementation:function(){try{var panel=$.NSOpenPanel.openPanel;panel.canChooseDirectories=true;panel.canChooseFiles=false;panel.allowsMultipleSelection=false;if(cocoaInteger(panel.runModal,'folder selection')===1){vaultPath=str(panel.URL.path);vaultField.stringValue=$(vaultPath);}}catch(error){alert(String(error));}}},
        'help:':{types:['void',['id']],implementation:function(){$.NSWorkspace.sharedWorkspace.openURL($.NSURL.URLWithString('https://learn.chatgpt.com/docs/cli/'));}}
    }});actions=$.WorkbenchInstallerActions.alloc.init;app.delegate=actions;
    var back=button(content,'Back',548,30,112,'back:'),next=button(content,'Continue',674,30,134,'next:');next.keyEquivalent='\r';
    var gateHint=label(content,'',222,66,586,20,11,false);gateHint.textColor=$.NSColor.secondaryLabelColor;
    function text(t,y,h,size,bold){return label(body,t,0,y,580,h,size||14,Boolean(bold));}
    function render(){while(body.subviews.count>0)body.subviews.objectAtIndex(0).removeFromSuperview;stepLabel.stringValue=$('1  Welcome\n\n2  License\n\n3  Vault\n\n4  Install\n\n5  Ready\n\nStep '+(step+1)+' of 5');back.hidden=step===0||step===4;back.enabled=true;next.enabled=true;gateHint.stringValue=$('');next.title=$(step===3?'Install':step===4?'Finish':'Continue');
        if(step===0){text('Your workspace. Connected.',387,80,30,true);text('Install Workbench for Obsidian',326,48,20,true);text('Bring your notes, Sources and AI conversations together.\n\nInstall into the Vault you choose. Existing notes, settings\nand Sessions are preserved.\n\nRenewable 30-day use license.\nNo administrator access or automatic subscription.',104,208);text('Requires Obsidian 1.15+ and your own supported model login.\nGit history and the Ollama classifier are optional.',12,70,13);}
        if(step===1){text('Review the license',410,52,28,true);text('Publisher-approved 30-day activation. No automatic billing.',364,38);var scroll=$.NSScrollView.alloc.initWithFrame($.NSMakeRect(0,64,580,288));scroll.hasVerticalScroller=true;scroll.borderType=$.NSBezelBorder;var view=$.NSTextView.alloc.initWithFrame($.NSMakeRect(0,0,560,288));view.string=$(terms);view.editable=false;view.richText=false;view.font=$.NSFont.systemFontOfSize(12);scroll.documentView=view;body.addSubview(scroll);agreeBox=checkbox('I agree to the Workbench 30-day use license.',12,accepted,'agree:');syncChecks();}
        if(step===2){text('Choose your Vault',410,52,28,true);text('Select an existing Vault containing an .obsidian folder.',353,44);vaultField=$.NSTextField.alloc.initWithFrame($.NSMakeRect(0,290,465,32));vaultField.stringValue=$(vaultPath);body.addSubview(vaultField);button(body,'Browse…',478,288,102,'browse:');enableBox=checkbox('Enable Workbench in this Vault',222,enabled,'enable:');text('Only Workbench program files and its install record change.\nExisting installation files are backed up inside the Vault.\nCommunity plugin restrictions are never disabled automatically.',89,118);closedBox=checkbox('I have closed Obsidian before installing.',18,closed,'closed:');syncChecks();}
        if(step===3){text('Ready to install',410,52,28,true);text('Workbench '+meta.version+'  ·  JoSH',350,44,20,true);text('Vault\n'+vaultPath+'\n\nLicense\n30 days from publisher-approved activation\n\nExisting notes and Sessions remain in place.',119,220);text('Restart Obsidian after installation. If Restricted mode is on,\nreview its community plugin notice yourself before enabling.',16,84);}
        if(step===4){text("You're ready",408,60,30,true);text('Workbench is installed',340,50,22,true);text('License activation\n'+expiry+'\n\n1. Restart Obsidian and open the selected Vault.\n2. Enable Workbench under Community plugins if needed.\n3. Connect your existing model account.\n\nUse Workbench license settings to activate or renew.\nModel subscriptions and CLI apps are not included.',80,250);button(body,'Official Codex setup guide',0,16,260,'help:');}
    }
    render();window.makeKeyAndOrderFront($());app.activateIgnoringOtherApps(true);app.run;
}
